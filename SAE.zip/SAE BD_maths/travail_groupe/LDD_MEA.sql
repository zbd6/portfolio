-- Définition des types ENUM
CREATE TYPE GENRE AS ENUM ('homme', 'femme', 'non-binaire');
CREATE TYPE TYPEABO AS ENUM ('gratuit', 'premium', 'entreprise');
CREATE TYPE TYPEREACT AS ENUM ('like', 'partage', 'commentaire', 'participation', 'evenement');

-- Table utilisateur
CREATE TABLE utilisateur (
    Id_utilisateur SERIAL,
    genre GENRE,
    username VARCHAR(50) NOT NULL,
    date_de_naissance DATE,
    niveau_d_education VARCHAR(50),
    type_d_abonnement TYPEABO NOT NULL,
    PRIMARY KEY (Id_utilisateur)
);

-- Table session
CREATE TABLE Session (
    Id_Session SERIAL,
    date_debut TIMESTAMP,
    date_fin TIMESTAMP,
    localisation VARCHAR(50),
    Id_utilisateur INT,
    PRIMARY KEY (Id_Session),
    FOREIGN KEY (Id_utilisateur) REFERENCES utilisateur(Id_utilisateur)
);

-- Table page
CREATE TABLE page (
    Id_page SERIAL,
    titre VARCHAR(50),
    PRIMARY KEY (Id_page)
);

-- Table pub
CREATE TABLE pub (
    Id_pub SERIAL,
    contenu VARCHAR(50),
    PRIMARY KEY (Id_pub)
);

-- Table notification
CREATE TABLE notification (
    Id_utilisateur INT,
    Id_Notification SERIAL,
    contenu VARCHAR(50),
    PRIMARY KEY (Id_utilisateur, Id_Notification),
    FOREIGN KEY (Id_utilisateur) REFERENCES utilisateur(Id_utilisateur)
);

-- Table publication
CREATE TABLE publication (
    Id_page INT,
    Id_utilisateur INT,
    Id_publication SERIAL,
    contenu VARCHAR(50),
    date_publication TIMESTAMP,
    PRIMARY KEY (Id_page, Id_utilisateur, Id_publication),
    FOREIGN KEY (Id_page) REFERENCES page(Id_page),
    FOREIGN KEY (Id_utilisateur) REFERENCES utilisateur(Id_utilisateur)
);

-- Table groupe
CREATE TABLE groupe (
    Id_page INT,
    Id_groupe SERIAL,
    PRIMARY KEY (Id_page, Id_groupe),
    FOREIGN KEY (Id_page) REFERENCES page(Id_page)
);

-- Table reaction
CREATE TABLE reaction (
    Id_page INT,
    Id_utilisateur INT,
    Id_publication INT,
    Id_utilisateur_1 INT,
    Id_reaction SERIAL,
    type TYPEREACT NOT NULL,
    contenu VARCHAR(50),
    PRIMARY KEY (Id_page, Id_utilisateur, Id_publication, Id_utilisateur_1, Id_reaction),
    FOREIGN KEY (Id_page, Id_utilisateur, Id_publication) REFERENCES publication(Id_page, Id_utilisateur, Id_publication),
    FOREIGN KEY (Id_utilisateur_1) REFERENCES utilisateur(Id_utilisateur)
);

-- Table rejoint
CREATE TABLE rejoint (
    Id_utilisateur INT,
    Id_page INT,
    Id_groupe INT,
    PRIMARY KEY (Id_utilisateur, Id_page, Id_groupe),
    FOREIGN KEY (Id_utilisateur) REFERENCES utilisateur(Id_utilisateur),
    FOREIGN KEY (Id_page, Id_groupe) REFERENCES groupe(Id_page, Id_groupe)
);

-- Table clique
CREATE TABLE clique (
    Id_Session INT,
    Id_pub INT,
    PRIMARY KEY (Id_Session, Id_pub),
    FOREIGN KEY (Id_Session) REFERENCES Session(Id_Session),
    FOREIGN KEY (Id_pub) REFERENCES pub(Id_pub)
);

-- Table message
CREATE TABLE message (
    Id_utilisateur INT,
    Id_utilisateur_1 INT,
    contenu VARCHAR(50),
    PRIMARY KEY (Id_utilisateur, Id_utilisateur_1),
    FOREIGN KEY (Id_utilisateur) REFERENCES utilisateur(Id_utilisateur),
    FOREIGN KEY (Id_utilisateur_1) REFERENCES utilisateur(Id_utilisateur)
);

-- Table accede_a
CREATE TABLE Accede_a (
    Id_Session INT,
    Id_page INT,
    PRIMARY KEY (Id_Session, Id_page),
    FOREIGN KEY (Id_Session) REFERENCES Session(Id_Session),
    FOREIGN KEY (Id_page) REFERENCES page(Id_page)
);

-- Table administre
CREATE TABLE administre (
    Id_utilisateur INT,
    Id_page INT,
    PRIMARY KEY (Id_utilisateur, Id_page),
    FOREIGN KEY (Id_utilisateur) REFERENCES utilisateur(Id_utilisateur),
    FOREIGN KEY (Id_page) REFERENCES page(Id_page)
);

-- Table Réponse_a
CREATE TABLE Réponse_a (
    Id_page INT,
    Id_utilisateur INT,
    Id_publication INT,
    Id_page_1 INT,
    Id_utilisateur_1 INT,
    Id_publication_1 INT,
    PRIMARY KEY (Id_page, Id_utilisateur, Id_publication, Id_page_1, Id_utilisateur_1, Id_publication_1),
    FOREIGN KEY (Id_page, Id_utilisateur, Id_publication)
        REFERENCES publication(Id_page, Id_utilisateur, Id_publication),
    FOREIGN KEY (Id_page_1, Id_utilisateur_1, Id_publication_1)
        REFERENCES publication(Id_page, Id_utilisateur, Id_publication)
);
